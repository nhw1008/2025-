import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    
    # LambdaA로부터 전달받은 인스턴스 ID 가져오기
    instance_id = event['instance_id']
    
    # EC2 인스턴스 시작
    ec2.start_instances(InstanceIds=[instance_id])
    
    return {'started': instance_id}
