import boto3

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    sns = boto3.client('sns')
    lam = boto3.client('lambda')
    
    instance_id = 'i-0aa015971c11dd16f'
    topic = 'arn:aws:sns:ap-northeast-2:443370697536:sgu-202503'
    lambda_b = 'sgu-202503-LambdaB'
    
    res = ec2.describe_instance_status(InstanceIds=[instance_id])
    
    # 상태 정보가 없으면 중지된 상태로 봄
    if res['InstanceStatuses']:
        state = res['InstanceStatuses'][0]['InstanceState']['Name']
    else:
        state = 'stopped'
    
    # 상태가 running이 아니면 알림 보내고 LambdaB 실행
    if state != 'running':
        msg = f"경고: EC2 인스턴스 {instance_id} 상태가 '{state}'입니다."
        sns.publish(TopicArn=topic, Subject='EC2 상태 알림', Message=msg)
        lam.invoke(FunctionName=lambda_b, InvocationType='Event',
                   Payload=f'{{"instance_id": "{instance_id}"}}')

    return {'state': state}
